A Pen created at CodePen.io. You can find this one at https://codepen.io/matttherault/pen/prxOgJ.

 Working on building a leaderboard for my underwear blog.